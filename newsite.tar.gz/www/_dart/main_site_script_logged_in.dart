import 'dart:html';
import 'dart:async';
import 'package:cb_common/json.dart';
import 'package:cb_common/site_classes.dart';
import 'package:cb_common/core.dart' ;
import 'package:cb_common/elements.dart' ;
import 'package:cb_common/user_settings.dart';
import 'package:christianbud_de/christian_budde_library.dart';


main() {

  runZoned(() {
    var initLib = new InitializerLibrary();

    debugger.enabled = body.classes.contains("debug");

    queryAll("select").forEach((e) => new BetterSelect(e));
    queryAll("ul.draggable").forEach((e) => new ChangeableList(e));

    initLib.registerInitializer(new UserSettingsInitializer(initLib));
    initLib.registerInitializer(new TopMenuInitializer());
    initLib.registerInitializer(new EditorInitializer(site, pageOrder, userLibrary));

    // PAGES
    initLib.registerInitializer(new LoginFormulaInitializer());
    initLib.registerInitializer(new FrontPageInitializer());
    initLib.registerInitializer(new StandardPageInitializer());
    initLib.registerInitializer(new ContactPageInitializer());

    initLib.setUp();

  }, onError : (ex, st) {
    ajaxClient.callFunction(new LogLogJSONFunction(ex.toString(), st.toString(), LogLogJSONFunction.LOG_LEVEL_ERROR));
  });


}