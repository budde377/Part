import 'dart:html';
import 'package:cb_common/core.dart' ;
import 'package:cb_common/elements.dart' ;
import 'package:cb_common/user_settings.dart';
import 'package:christianbud_de/christian_budde_library.dart';



main() {

  var initLib = new InitializerLibrary();

  debugger.enabled = body.classes.contains("debug");

  queryAll("select").forEach((e)=>new BetterSelect(e));
  queryAll("ul.draggable").forEach((e)=>new ChangeableList(e));

  initLib.registerInitializer(new TopMenuInitializer());
  initLib.registerInitializer(new LoginFormulaInitializer());
  initLib.registerInitializer(new FrontPageInitializer());
  initLib.registerInitializer(new StandardPageInitializer());
  initLib.registerInitializer(new ContactPageInitializer());
  initLib.setUp();




}

