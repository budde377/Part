library christian_budde_library;
import "dart:html";
import "dart:math" as Math;
import "dart:async";
import 'package:cb_common/user_settings.dart' as UserSettings;
import 'package:cb_common/core.dart';
import 'package:cb_common/elements.dart';
import 'package:cb_common/site_classes.dart';
import 'package:cb_common/json.dart' ;

class TopMenuInitializer implements Initializer {
  Element _element = query("#TopMenu"), _activeBar = new DivElement();

  Animation _currentAnimation;

  LIElement _currentLi;

  int _currentLiIndex;

  int _currentBGPos;

  final List<dynamic> _subscriptions = new List<dynamic>();

  PageOrder _pageOrder;


  bool get canBeSetUp => _element != null;


  int _calculateBGPosition(int no) => 200 * no + 71;

  int _calculateIndex(Element e) {
    var index = 0, p = e.previousElementSibling;
    while (p != null) {
      if (!e.hidden) {
        index++;
      }
      p = p.previousElementSibling;
    }
    return index;
  }

  void setUp() {
    _setUpPageOrder();
    _currentLi = _element.query('li.active');
    if (_currentLi == null) {
      return;
    }
    _element.classes.add('noArrow');
    _activeBar.classes.add('activeBar');
    _element.append(_activeBar);
    _currentLiIndex = _calculateIndex(_currentLi);
    _setBGPos(_calculateBGPosition(_currentLiIndex));
    _setUpListeners();
    _element.onChange.listen((e) => _refresh());

  }

  void _setUpPageOrder() {
    if (!UserSettings.pageOrderAvailable) {
      return;
    }
    var ul = _element.children.first;
    var addPageListener = (LIElement li) {
      AnchorElement a = li.query('a');
      if (a == null) {
        return;
      }
      var id = UserSettings.idFromAnchor(a);
      Page p = _pageOrder.pages[id];
      if (p == null) {
        return;
      }
      p.onChange.listen((_) {
        a
          ..text = p.title
          ..href = "/" + p.id;
        if (li.hidden != p.hidden) {
          li.hidden = p.hidden;
          _refresh();
        }
      });

    };

    _pageOrder = UserSettings.pageOrder;
    ul.children.forEach(addPageListener);
    _pageOrder.onUpdate.listen((PageOrderChange change) {
      var changeType = change.type, page = change.page;
      if (changeType == PageOrderChange.PAGE_ORDER_CHANGE_CREATE_PAGE) {
        return;
      }
      ul.children.clear();
      _pageOrder.listPageOrder().forEach((Page p) {
        var li = new LIElement();
        var a = new AnchorElement();
        if (p == _pageOrder.currentPage) {
          li.classes.add('active');
        }

        a
          ..text = p.title
          ..href = "/" + p.id;
        li.hidden = p.hidden;

        li.append(a);
        addPageListener(li);
        ul.append(li);
        _refresh();
      });
    });
  }

  void _setUpListeners() {
    int index = 0;
    var move = (int duration, int newPos, int startPos) {
      _stop();
      _currentAnimation = new Animation(new Duration(milliseconds:duration), (double pct) => _setBGPos((startPos + (newPos - startPos) * pct).toInt()));
      _currentAnimation.start();
    };
    var liList = _element.queryAll('li').toList();
    liList.removeWhere((LIElement li) => li.hidden);
    liList.forEach((LIElement li) {
      var i = index;
      index++;
      if (li == _currentLi) {
        return;
      }
      _subscriptions.add(li.onClick.listen((MouseEvent e) => _cancelEvents()));
      _subscriptions.add(li.onMouseOver.listen((MouseEvent e) => move(200, _calculateBGPosition(i), _currentBGPos)));
      _subscriptions.add(li.onMouseOut.listen((MouseEvent e) => move(150, _calculateBGPosition(_currentLiIndex), _currentBGPos)));

    });
  }


  void _refresh() {
    _cancelEvents();
    if ((_currentLi = _element.query('li.active')) == null || (_currentLi = _currentLi.hidden ? null : _currentLi) == null) {
      _currentLiIndex = null;
      _element.classes.remove('noArrow');
      _activeBar.remove();
      return;
    }
    if (!_element.classes.contains('noArrow')) {
      _element.append(_activeBar);
      _element.classes.add('noArrow');
    }
    _setBGPos(_calculateBGPosition(_currentLiIndex = _calculateIndex(_currentLi)));
    _setUpListeners();
  }

  void _stop() {
    if (_currentAnimation != null) {
      _currentAnimation.stop();
    }
  }

  void _cancelEvents() => _subscriptions.forEach((s) => s.cancel());

  void _setBGPos(int pos) {
    _currentBGPos = pos;
    _activeBar.style.backgroundPosition = "${_currentBGPos}px bottom";
  }

}


class FrontPageInitializer implements Initializer{

  Element _dias = query("#FrontPageDias > ul");

  Element _diasMenu = query("#FrontPageDiasMenu > ul");

  bool get canBeSetUp => _dias != null && _diasMenu != null;

  void setUp() {
    var d = new ElementDiasDecoration(_dias);
    d.onIndexChange.listen((int i){
      var active = _diasMenu.query(".active");
      if(active != null){
        active.classes.remove("active");
      }
      _diasMenu.children[i].classes.add("active");
    });



    var timerFunc = () => new Timer.periodic(new Duration(seconds:10), (Timer timer){
      d.next();
    });
    var timer = timerFunc();
    _diasMenu.onClick.listen((MouseEvent evt){
      if(!_diasMenu.children.contains(evt.toElement)){
        return;
      }
      timer.cancel();
      d.currentIndex = _diasMenu.children.indexOf(evt.toElement);


    });

  }

}


class StandardPageInitializer implements Initializer{

  Animation _scrollAnimation;

  Element _pageMenu = query("#StandardPageMenu > div");

  Element _contentElement = query("#StandardPageText .editable");

  bool get canBeSetUp => _pageMenu != null && _contentElement != null;

  void setUp() {

    _pageMenu.onClick.listen((MouseEvent evt){
      var a = evt.toElement;
      if(!(a is AnchorElement)){
        return;
      }
      if(a.hash.trim().length == 0){
        return;
      }
      var elm = query(a.hash);
      if(elm == null){
        return;
      }
      var s = document.body.scrollTop;
      window.location.hash = a.hash;
      document.body.scrollTop = s;
      scroll.scrollToElement(elm, animationFunction:Animation.easeInOutCirc);
      evt.preventDefault();
    });

    new FloatingElementHandler(_pageMenu);
    var editor = new ContentEditor.getCached(_contentElement);
    if(editor == null){
      return;
    }

    editor.onChange.listen((_) => _updateHeaders());
    editor.onSave.listen((_) {
      var jobid = savingBar.startJob();
      _updateHeaders();
      UserSettings.pageOrder.currentPage["standardLeftMenu"].addContent(_pageMenu.innerHtml).then((_)=>savingBar.endJob(jobid));
    });
  }

  void _updateHeaders(){

    var headerList = _contentElement.queryAll("h2, h3");
    _pageMenu.children.clear();
    var ul = new UListElement(), subUl;
    _pageMenu.append(ul);
    headerList.forEach((HeadingElement h){

      if(h.text.trim() == ""){
        return;
      }

      var li = new LIElement(),
          a = new AnchorElement();

      a.text = h.text;

      a.href = "#${h.id}";
      li.append(a);

      if(h.tagName == "H2"){
        ul.append(li);
        subUl = null;

      } else {
        if(subUl == null){
          subUl = new UListElement();
          ul.append(subUl);
        }
        subUl.append(li);
      }

    });

  }

}


class ContactPageJSONFunction extends JSONFunction{
  ContactPageJSONFunction(String name): super("ContactPage.${name}");
}

class UpdateReceiverContactPageJSONFunction extends ContactPageJSONFunction{
  UpdateReceiverContactPageJSONFunction(String mail) : super("updateReceiver"){
    arguments["mail"] = mail;
  }
}

class SendMailContactPageJSONFunction extends ContactPageJSONFunction{
  SendMailContactPageJSONFunction(String name, String mail, String subject, String message) : super("sendMail"){
    arguments["name"] = name;
    arguments["mail"] = mail;
    arguments["subject"] = subject;
    arguments["message"] = message;
  }
}


class ContactPageInitializer implements Initializer{

  FormElement _contactForm = query("form#ContactPageForm");

  bool get canBeSetUp => _contactForm != null;

  void setUp() {
    var validator = new FormValidator(_contactForm);
    validator.formHandler.submitFunction = ((Map<String, String> m){
      if(!validator.valid){
        return;
      }
      validator.formHandler.blur();
      ajaxClient.callFunction(new SendMailContactPageJSONFunction(m["name"], m["mail"], m["subject"], m["message"])).then((JSONResponse response){
        validator.formHandler.unBlur();
        validator.formHandler.clearForm();
        validator.formHandler.changeNotion("Beskeden er sendt", FormHandler.NOTION_TYPE_SUCCESS);
      });
    });

    var changeForm = query("form#ContactPageEditMailForm");
    if(changeForm == null || !UserSettings.userLibraryAvailable ||
        UserSettings.userLibrary.userLoggedIn == null){
      return;
    }
    var validator2 = new FormValidator(changeForm);
    InputElement textField = changeForm.query("input[type=email]");
    var v1 = textField.value;
    validator2.formHandler.submitFunction = ((Map<String, String> m){
      if(!validator2.valid || v1 == textField.value){
        return;
      }
      validator2.formHandler.blur();
      ajaxClient.callFunction(new UpdateReceiverContactPageJSONFunction(m["mail"])).then((JSONResponse response){
        validator2.formHandler.unBlur();
        textField.value = m["mail"].trim();
        v1 = textField.value;
      });

    });

  }

}


class LoginFormulaInitializer implements Initializer {
  FormElement _loginForm = query("form#UserLoginForm");

  bool get canBeSetUp => _loginForm != null;

  void setUp() {
    var form = new FormHandler(_loginForm);
    var client = new AJAXJSONClient();
    form.submitFunction = (Map<String, String> data) {
      form.blur();
      client.callFunction(new UserLoginJSONFunction(data['username'], data['password'])).then((JSONResponse response) {
        if (response.type == JSONResponse.RESPONSE_TYPE_ERROR) {
          form.unBlur();
          switch (response.error_code) {
            case JSONResponse.ERROR_CODE_USER_NOT_FOUND:
              form.changeNotion("Ugyldig bruger", FormHandler.NOTION_TYPE_ERROR);
              break;
            case JSONResponse.ERROR_CODE_WRONG_PASSWORD:
              form.changeNotion("Ugyldig kodeord", FormHandler.NOTION_TYPE_ERROR);
              break;
          }
        } else {
          form.changeNotion("Du er nu logget ind", FormHandler.NOTION_TYPE_SUCCESS);
          window.location.href = "/?" + new DateTime.now().millisecondsSinceEpoch.toString();
        }

      });
      return false;
    };
  }

}
