import 'dart:html';
import 'package:cb_common/core.dart' ;
import 'package:cb_common/elements.dart' ;
import 'package:cb_common/user_settings.dart';


main() {

  var initLib = new InitializerLibrary();

  debugger.enabled = body.classes.contains("debug");

  queryAll("select").forEach((e)=>new BetterSelect(e));
  queryAll("ul.draggable").forEach((e)=>new ChangeableList(e));

  initLib.setUp();


}

